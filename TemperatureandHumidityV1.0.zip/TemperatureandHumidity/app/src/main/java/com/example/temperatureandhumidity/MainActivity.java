package com.example.temperatureandhumidity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private TextView temp,hum;
    private Button refresh;
    static FirebaseDatabase database = FirebaseDatabase.getInstance();
    static DatabaseReference tempRef = database.getReference("Temperature");
    DatabaseReference humRef = database.getReference("Humidity");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        temp = findViewById(R.id.showtemp);
        hum = findViewById(R.id.showhum);
        refresh = findViewById(R.id.btnrefresh);

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentValues();
            }
        });
    }

    public void getCurrentValues(){

        // Read from the database
        tempRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                //Toast.makeText(MainActivity.this,"Temperature is : " +value,Toast.LENGTH_SHORT).show();
                temp.setText(value);
                //Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                //Log.i(TAG, "Failed to read value.", error.toException());
                Toast.makeText(MainActivity.this,"Failed to get Value from Database ",Toast.LENGTH_SHORT).show();
            }
        });

        humRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue().toString();
                //Toast.makeText(MainActivity.this,"Humidity is : " +value,Toast.LENGTH_SHORT).show();
                hum.setText(value);
                //Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                //Log.i(TAG, "Failed to read value.", error.toException());
                Toast.makeText(MainActivity.this,"Failed to get Value from Database ",Toast.LENGTH_SHORT).show();
            }
        });



    }

}
