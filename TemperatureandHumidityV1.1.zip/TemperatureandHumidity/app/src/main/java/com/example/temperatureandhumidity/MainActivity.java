package com.example.temperatureandhumidity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    double currtemp;
    String currtempcs;
    double currtempf;
    String currtempfs;

    private TextView temp,hum;
    private Button refresh;
    private Spinner tempspinner;
    static FirebaseDatabase database = FirebaseDatabase.getInstance();
    static DatabaseReference tempRef = database.getReference("Temperature");
    DatabaseReference humRef = database.getReference("Humidity");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        temp = findViewById(R.id.showtemp);
        hum = findViewById(R.id.showhum);
        refresh = findViewById(R.id.btnrefresh);
        tempspinner = findViewById(R.id.spntemp);

        String[] items = new String[]{"°C", "°F"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_spinner_dropdown_item, items);
        tempspinner.setAdapter(adapter);

        tempspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                    case 0:temp.setText(currtempcs);
                        break;
                    case 1:temp.setText(currtempfs);
                    break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getCurrentValues();
            }
        });
    }

    public void getCurrentValues(){

        // Read from the database
        tempRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and agaain whenever data at this location is updated.
                String tempvalue = dataSnapshot.getValue().toString();
                currtemp = Double.valueOf(tempvalue).doubleValue();
                currtempcs = String.valueOf(currtemp).toString();
                currtempf = (currtemp*1.8)+32;
                currtempfs = String.valueOf(currtempf).toString();
                //Toast.makeText(MainActivity.this,"Temperature is : " +tempvalue,Toast.LENGTH_SHORT).show();
                temp.setText(tempvalue);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(MainActivity.this,"Failed to get Value from Database ",Toast.LENGTH_SHORT).show();
            }
        });

        humRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again whenever data at this location is updated.
                String humvalue = dataSnapshot.getValue().toString();
                //Toast.makeText(MainActivity.this,"Humidity is : " +humvalue,Toast.LENGTH_SHORT).show();
                hum.setText(humvalue);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Toast.makeText(MainActivity.this,"Failed to get Value from Database ",Toast.LENGTH_SHORT).show();
            }
        });

    }

}
